package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Usuario;
import com.example.demo.service.UsuarioService;

@RestController
public class MainController {

	private UsuarioService usuarioServ;

	@Autowired
	public MainController(UsuarioService usServ) {

		this.usuarioServ = usServ;
	}

	@RequestMapping(value = { "/atos" }, method = RequestMethod.GET)

	public String listarTodos() {

		return "ATOS CODING MACHINES MANDAN!";

	}

	@RequestMapping(value = { "/atos/users" }, method = RequestMethod.GET)

	public List<Usuario> listarTodosUsers() {

		List<Usuario> usuarios = usuarioServ.geAllPersonas();

		return usuarios;

	}

}

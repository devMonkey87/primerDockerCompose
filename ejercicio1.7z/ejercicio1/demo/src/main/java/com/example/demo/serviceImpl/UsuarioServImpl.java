package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Usuario;
import com.example.demo.repository.UsuarioRepo;
import com.example.demo.service.UsuarioService;

@Service
public class UsuarioServImpl implements UsuarioService {

	private final UsuarioRepo usuarioRepo;

	@Autowired
	public UsuarioServImpl(UsuarioRepo usuRepo) {

		this.usuarioRepo = usuRepo;
	}

	@Override
	public List<Usuario> geAllPersonas() {

		List<Usuario> usuarios = usuarioRepo.findAll();
		return usuarios;
	}

}
